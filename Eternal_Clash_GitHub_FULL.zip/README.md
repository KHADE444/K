# Eternal Clash - Prototype

A minimal 5v5 MOBA prototype built with Python and Pygame.

## Features
- 5v5 heroes (1 player-controlled, rest AI)
- Minion waves, towers, basic combat
- Dynamic map shift event every 30s
- Stance toggle (Q key)

## Controls
- **WASD** - Move
- **SPACE** - Attack
- **Q** - Toggle stance
- **ESC** - Quit

## Installation & Running
1. Install Python 3.8+
2. Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```
3. Run the game:
    ```bash
    python Eternal_Clash_prototype.py
    ```

## Notes
This is an early prototype. It can be expanded with abilities, networking, animations, and more advanced AI.
