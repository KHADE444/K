"""
Eternal Clash - Minimal 5v5 MOBA prototype (single-file)
Requirements: Python 3.8+ and pygame
Install pygame: pip install pygame
Run: python Eternal_Clash_prototype.py

Controls (player controls a single hero - blue team):
 - WASD to move
 - Space to attack (basic range attack)

What this prototype includes (simplified):
 - 5v5 heroes represented as circles (AI-controlled teammates & enemies)
 - Three lanes with simple minion wave spawns moving toward enemy base
 - Towers that attack enemies in range
 - Basic health, damage, and respawn mechanics
 - A "map shift" event every 30 seconds that changes certain walkable tiles (visual only)
 - Hero stance swap (press 'Q' to toggle) which alters attack behavior

This is a starting point: expand by adding abilities, animations, pathfinding, networking, UI, and real items.

"""

import pygame
import random
import math
import time

# ----- Config -----
WIDTH, HEIGHT = 1200, 720
FPS = 60

LANE_Y = {'top': 140, 'mid': HEIGHT//2, 'bot': HEIGHT-140}
MINION_SPAWN_INTERVAL = 8.0  # seconds
MAP_SHIFT_INTERVAL = 30.0  # seconds

# Colors
WHITE = (255,255,255)
BLACK = (0,0,0)
GRAY = (100,100,100)
BLUE = (50,130,230)
RED = (230,70,70)
GREEN = (80,200,120)
YELLOW = (235,210,100)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Eternal Clash - Prototype")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

# ----- Utility -----

def dist(a,b):
    return math.hypot(a[0]-b[0], a[1]-b[1])

# ----- Game Entities -----
class Tower:
    def __init__(self, x, y, team):
        self.x = x
        self.y = y
        self.team = team
        self.range = 160
        self.hp = 1000
        self.max_hp = 1000
        self.size = 36

    def is_enemy(self, other):
        return other.team != self.team

    def draw(self, surf):
        color = BLUE if self.team==0 else RED
        pygame.draw.rect(surf, color, (self.x-self.size//2, self.y-self.size//2, self.size, self.size))
        # HP bar
        ratio = max(self.hp,0)/self.max_hp
        pygame.draw.rect(surf, BLACK, (self.x-30, self.y-40, 60, 6))
        pygame.draw.rect(surf, GREEN, (self.x-30, self.y-40, int(60*ratio), 6))

    def update(self, world):
        # attack nearest enemy in range
        target = None
        bestd = 9999
        for e in world.entities:
            if hasattr(e,'team') and self.is_enemy(e) and e.hp>0:
                d = dist((self.x,self.y),(e.x,e.y))
                if d < self.range and d < bestd:
                    bestd = d
                    target = e
        if target:
            target.take_damage(20*1/FPS)  # per-frame small damage


class Minion:
    def __init__(self, lane, team, x):
        self.lane = lane
        self.team = team
        self.x = x
        self.y = LANE_Y[lane]
        self.speed = 40 + random.uniform(-6,6)
        self.hp = 120
        self.max_hp = 120
        self.radius = 10
        self.damage = 15

    def draw(self, surf):
        color = BLUE if self.team==0 else RED
        pygame.draw.circle(surf, color, (int(self.x), int(self.y)), self.radius)
        ratio = max(self.hp,0)/self.max_hp
        pygame.draw.rect(surf, BLACK, (self.x-12, self.y-22, 24, 4))
        pygame.draw.rect(surf, GREEN, (self.x-12, self.y-22, int(24*ratio), 4))

    def update(self, world):
        # move toward enemy base
        dir = 1 if self.team==0 else -1
        self.x += dir*self.speed/FPS
        # check collisions with enemy minions
        for e in world.entities:
            if isinstance(e, Minion) and e.team!=self.team and abs(e.y-self.y)<20 and abs(e.x-self.x)<22:
                # simple fight: both take damage
                e.hp -= self.damage*(1/FPS)
                self.hp -= e.damage*(1/FPS)
        # towers
        for t in world.towers:
            if t.team!=self.team and dist((self.x,self.y),(t.x,t.y))<t.range:
                self.hp -= 30*(1/FPS)
        if self.hp<=0:
            world.mark_for_removal(self)

class Hero:
    def __init__(self, x, y, team, controllable=False, name='Hero'):
        self.x = x
        self.y = y
        self.team = team
        self.hp = 800
        self.max_hp = 800
        self.radius = 16
        self.speed = 120
        self.damage = 60
        self.attack_range = 80
        self.attack_cooldown = 0.9
        self.cd_timer = 0.0
        self.controllable = controllable
        self.name = name
        self.target = None
        self.stance = 0  # 0 offense, 1 defense
        self.respawn_time = 4.0
        self.dead_timer = 0.0

    def draw(self, surf):
        if self.hp<=0:
            return
        color = BLUE if self.team==0 else RED
        pygame.draw.circle(surf, color, (int(self.x), int(self.y)), self.radius)
        # stance indicator
        if self.stance==0:
            pygame.draw.circle(surf, YELLOW, (int(self.x)-10, int(self.y)-18), 5)
        else:
            pygame.draw.circle(surf, GREEN, (int(self.x)-10, int(self.y)-18), 5)
        # HP bar
        ratio = max(self.hp,0)/self.max_hp
        pygame.draw.rect(surf, BLACK, (self.x-20, self.y-30, 40, 6))
        pygame.draw.rect(surf, GREEN, (self.x-20, self.y-30, int(40*ratio), 6))
        # name
        txt = font.render(self.name, True, WHITE)
        surf.blit(txt, (self.x-20, self.y-44))

    def take_damage(self, d):
        self.hp -= d
        if self.hp<=0:
            self.dead_timer = self.respawn_time

    def attack(self, world):
        # basic area instant attack for simplicity
        if self.cd_timer>0 or self.hp<=0:
            return
        # find target in range prioritized
        target = None
        bestd = 9999
        for e in world.entities:
            if hasattr(e,'team') and e.team!=self.team and getattr(e,'hp',0)>0:
                d = dist((self.x,self.y),(e.x,e.y))
                if d <= self.attack_range and d<bestd:
                    bestd = d
                    target = e
        if target:
            dmg = self.damage * (1.2 if self.stance==0 else 0.85)
            target.take_damage(dmg)
            self.cd_timer = self.attack_cooldown * (0.85 if self.stance==0 else 1.15)

    def take_action(self, world, keys):
        if self.hp<=0:
            return
        if self.controllable:
            # movement
            dx = (keys[pygame.K_d]-keys[pygame.K_a])
            dy = (keys[pygame.K_s]-keys[pygame.K_w])
            if dx!=0 or dy!=0:
                norm = math.hypot(dx,dy)
                self.x += (dx/norm)*self.speed/FPS
                self.y += (dy/norm)*self.speed/FPS
                self.x = max(40, min(WIDTH-40, self.x))
                self.y = max(40, min(HEIGHT-40, self.y))
        else:
            # very simple AI: move along lane if assigned
            if hasattr(self,'lane'):
                target_x = 100 if self.team==1 else WIDTH-100
                dir = -1 if self.team==1 else 1
                goal_y = LANE_Y[self.lane]
                self.x += dir*self.speed/FPS
                self.y += (goal_y - self.y)*0.05
        self.cd_timer = max(0.0, self.cd_timer - 1/FPS)

    def update(self, world):
        if self.hp<=0:
            self.dead_timer -= 1/FPS
            if self.dead_timer<=0:
                self.hp = self.max_hp
                if self.team==0:
                    self.x, self.y = 80, HEIGHT//2
                else:
                    self.x, self.y = WIDTH-80, HEIGHT//2
            return
        if not self.controllable:
            for e in world.entities:
                if hasattr(e,'team') and e.team!=self.team and getattr(e,'hp',0)>0:
                    if dist((self.x,self.y),(e.x,e.y))<=self.attack_range:
                        e.take_damage(self.damage*(1.2 if self.stance==0 else 0.9)*(1/FPS))
        self.x = max(20, min(WIDTH-20, self.x))
        self.y = max(20, min(HEIGHT-20, self.y))

class World:
    def __init__(self):
        self.entities = []
        self.towers = []
        self.remove_list = []
        self.minion_timers = { 'top':0.0, 'mid':0.0, 'bot':0.0 }
        self.last_minion_spawn = time.time()
        self.last_map_shift = time.time()
        self.map_shift_state = 0

    def add(self, e):
        self.entities.append(e)

    def mark_for_removal(self, e):
        if e not in self.remove_list:
            self.remove_list.append(e)

    def process_removals(self):
        for e in self.remove_list:
            if e in self.entities:
                self.entities.remove(e)
        self.remove_list = []

    def spawn_minion_wave(self, lane):
        left_start = 180
        right_start = WIDTH-180
        for i in range(3):
            m1 = Minion(lane, 0, left_start - i*24)
            m2 = Minion(lane, 1, right_start + i*24)
            self.add(m1); self.add(m2)

    def spawn_heroes(self):
        names = ['Kael','Veyra','Torvak','Lyra','Bram']
        for i in range(5):
            h = Hero(120, 120 + i*40, 0, controllable=(i==0), name=names[i])
            if i>0:
                h.lane = random.choice(['top','mid','bot'])
            self.add(h)
        for i in range(5):
            h = Hero(WIDTH-120, HEIGHT-120 - i*40, 1, controllable=False, name='E'+names[i])
            if i>0:
                h.lane = random.choice(['top','mid','bot'])
            self.add(h)

    def spawn_towers(self):
        positions = [ (260, LANE_Y['top']), (260, LANE_Y['mid']), (260, LANE_Y['bot']) ]
        for x,y in positions:
            self.towers.append(Tower(x,y,0))
        positions_r = [ (WIDTH-260, LANE_Y['top']), (WIDTH-260, LANE_Y['mid']), (WIDTH-260, LANE_Y['bot']) ]
        for x,y in positions_r:
            self.towers.append(Tower(x,y,1))

    def update(self, keys):
        tnow = time.time()
        if tnow - self.last_minion_spawn > MINION_SPAWN_INTERVAL:
            for lane in ['top','mid','bot']:
                self.spawn_minion_wave(lane)
            self.last_minion_spawn = tnow
        if tnow - self.last_map_shift > MAP_SHIFT_INTERVAL:
            self.map_shift_state = (self.map_shift_state + 1) % 3
            self.last_map_shift = tnow
        for t in self.towers:
            t.update(self)
        for e in list(self.entities):
            if isinstance(e, Hero):
                if e.controllable:
                    e.take_action(self, keys)
                else:
                    e.take_action(self, keys)
                e.update(self)
            elif isinstance(e, Minion):
                e.update(self)
        for e in self.entities:
            if isinstance(e, Hero) and e.controllable:
                if keys[pygame.K_SPACE]:
                    e.attack(self)
        self.process_removals()

    def draw(self, surf):
        surf.fill((16,22,30))
        for lane in LANE_Y.values():
            pygame.draw.line(surf, (50,60,80), (0,lane), (WIDTH,lane), 2)
        for t in self.towers:
            t.draw(surf)
        for e in self.entities:
            e.draw(surf)
        txt = font.render(f"Map shift state: {self.map_shift_state} (every {MAP_SHIFT_INTERVAL}s)", True, WHITE)
        surf.blit(txt, (10,10))
        txt2 = font.render("Controls: WASD to move, SPACE attack, Q toggle stance", True, WHITE)
        surf.blit(txt2, (10,30))

def main():
    world = World()
    world.spawn_towers()
    world.spawn_heroes()
    running = True
    while running:
        dt = clock.tick(FPS)/1000.0
        keys = pygame.key.get_pressed()
        for ev in pygame.event.get():
            if ev.type==pygame.QUIT:
                running = False
            if ev.type==pygame.KEYDOWN:
                if ev.key==pygame.K_q:
                    for e in world.entities:
                        if isinstance(e, Hero) and e.team==0:
                            e.stance = 1 - e.stance
        world.update(keys)
        world.draw(screen)
        pygame.display.flip()
    pygame.quit()

if __name__=='__main__':
    main()
